## Deployment: Applikation verteilen

Deployment bedeutet: Eine fertige Anwendung wird auf ein Zielsystem übertragen, auf dem sie ausgeführt werden soll.

Bei **Plattformanwendungen** (also nicht Web) ist das **etwas aufwändiger**, weil man das Programm nicht einfach im Browser aufrufen kann.

### .NET und das Zielsystem

Bei .NET stellt sich die Frage:  
**Ist die .NET Runtime auf dem Zielsystem bereits installiert – oder nicht?**

Das beeinflusst den **Publish-Vorgang**. Denn beim Veröffentlichen kann man wählen:

- **Framework-abhängig**: Kleinere App, benötigt .NET-Installation auf dem Zielsystem  
- **Self-contained**: Größere App, aber läuft **ohne installierte .NET-Runtime**
- **Trimmed**: Nur tatsächlich benötigte Teile des Frameworks werden mitgepackt – spart Speicherplatz

Zusätzlich und kombiniert damit ist möglich
- **SingleFile**: Nur eine einzige Datei (die aber beim ersten Start in ein verstecktes Verzeichnis entpackt wird)
- **AOT**: (nimmt nötige .Net-Funktionalilät mit) Auf die Zielplattform optimiert, minimal mögliche Größe, maximal mögliche Performance, aber mit Einschränkungen bei der sog. Reflection

Zielplattformen (unter anderem, also für uns relevant)
- Windows  
- Linux  
- macOS  

(Mobile Plattformen wären wieder ein anderes Thema – für Konsolen-Apps aber nicht relevant.)

---

### Der zentrale Befehl: `dotnet publish`

Vom Visual Studio Code aus nutzen wir das **.NET CLI**.

Es bietet den Befehl `dotnet publish`, mit dem wir genau dieses Deployment durchführen.

Also los – publizieren wir unsere `LocalizeHelper`-Applikation!

`dotnet publish` nimmt Standardvorgaben (aktuelles OS, Release-Version, frameworkabhängig).
Aber interessant wird es natürlich mit den Optionen.
Publizieren wir zunächst einmal die Release-Version – frameworkabhängig – für alle Plattformen.

#### Framework-abhängig (Framework-Dependent)
Die Zielplattform muss .NET bereits installiert haben:
- `dotnet publish -c Release -r win-x64 --self-contained false`
- `dotnet publish -c Release -r linux-x64 --self-contained false`
- `dotnet publish -c Release -r osx-x64 --self-contained false`

#### Selbstenthaltend (Self-Contained)
.NET wird mitgeliefert – keine Abhängigkeit vom Zielsystem:
- `dotnet publish -c Release -r win-x64 --self-contained true`
- `dotnet publish -c Release -r linux-x64 --self-contained true`
- `dotnet publish -c Release -r osx-x64 --self-contained true`

#### Einzeldatei (Single File)
Optional zu self-contained – fasst alles in eine einzige ausführbare Datei:
- `dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true`
- `dotnet publish -c Release -r linux-x64 --self-contained true /p:PublishSingleFile=true`
- `dotnet publish -c Release -r osx-x64 --self-contained true /p:PublishSingleFile=true`

#### Getrimmt + Single File
Reduziert die Dateigröße durch Entfernen unbenutzter Teile des Frameworks:
- `dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:PublishTrimmed=true`
- `dotnet publish -c Release -r linux-x64 --self-contained true /p:PublishSingleFile=true /p:PublishTrimmed=true`
- `dotnet publish -c Release -r osx-x64 --self-contained true /p:PublishSingleFile=true /p:PublishTrimmed=true`

#### Ahead-of-Time (AOT) Kompilierung
Noch kompakter und schnellerer Start, aber Plattform-spezifisch und mit Einschränkungen:
- `dotnet publish -c Release -r win-x64 /p:PublishAot=true`
- `dotnet publish -c Release -r linux-x64 /p:PublishAot=true`
- `dotnet publish -c Release -r osx-x64 /p:PublishAot=true`

Hinweis: AOT benötigt das .NET SDK 7.0 oder neuer und ist nur mit kompatiblen Projekten möglich (z. B. Konsolenanwendungen, ohne dynamische Reflection).

## Und ausprobieren

Also probieren wir das aus. Publizieren wir das Projekt für Windows, als Single-File, frameworkunabhängig.

Wir sehen hier im Ausgabeverzeichnis `win-x64` die publizierten Dateien. Aber es gibt noch einen Unterordner `publish`, der tatsächlich nur die ausführbare Datei `LocalizeHelper.exe`, die zugehörigen Debug-Informationen in der Datei mit der Endung `.pdb`, und unsere Beispieldateien enthält.

Mit 15 Megabyte ist es – na ja – sagen wir: einigermaßen kompakt.

Lassen wir es mal laufen. Wir sehen unser gewohntes Menü.

Geben wir mal ein: `csv-to-resx`, den Dateinamen `Demo.Translation.csv`, die Zielsprachen `en fr` und starten das Ganze.

Ups! Das Programm ist verschwunden – aber wir sehen im Verzeichnis die erzeugten `.resx`-Dateien.

Die Anwendung hat sich nur beendet, weil sie nicht aus der Konsole heraus gestartet wurde, sondern per Doppelklick.
