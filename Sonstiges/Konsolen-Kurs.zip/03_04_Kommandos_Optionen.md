## Kommandos und Optionen
Wir haben zwei Kommandos: `resx-to-csv` und `csv-to-resx`.  
Diese sollen **immer zuerst** angegeben werden – danach folgt der **Pfad zur Datei** und schließlich eine **Liste von Zielsprachen** im **ISO-Format**, zum Beispiel `en` und `fr`.

---

### args in einer Klasse auswerten
Wir starten die `Main`-Methode mit der **Auswertung des `args`-Arrays**:  
Wir erwarten also zuerst das Kommando, den Datei-Pfad und mindestens eine Sprache als ISO-Code.

Dafür bietet sich eine eigene Klasse an – nennen wir sie `CommandInfo`. Erzeugen wir diese in einer **neuen Datei**. Anstatt die Datei über die Dateiansicht in Visual Studio Code anzulegen,  
machen wir das eleganter über das **.NET CLI**:

`dotnet new class -n CommandInfo`

Wir sehen eine leere neue Klasse im richtigen Namespace. Füllen wir sie mit Leben! Wir brauchen das Kommando, den InputText (den wir aus dem Dateipfad einlesen werden) und die Liste der Zielsprachen. Für ersteres bietet sich ein enum-Typ an. Also Legen wir diesen an: Commands.ResXToCsv und Commands.CsvToResX sind die möglichen Werte. Dann fügen wir die Properties Command, InputText und LanguageCodes ein. Als letztes noch eine statische Methode Create mit einem übergebenen String-Array, die dann die passende CommandInfo zurückgibt.  

---

### Immutable-,  NullObject- und Factory-Pattern 
Die Properties in `CommandInfo` setzen wir auf **read-only** – also nur mit Getter. Zusätzlich definieren wir einen **privaten Konstruktor**.

Warum das Ganze?

Durch die **read-only Properties** wird die Instanz **immutable** – also nach der Erzeugung nicht mehr veränderbar.  
Das ist ein modernes Programmierparadigma im .NET-Umfeld für **sauberen, wartbaren Code**.

Ein **immutable Objekt**:
- kann nach der Erzeugung nicht verändert werden,
- ist **thread-sicher**,
- und bleibt frei von **Seiteneffekten**.

Der **private Konstruktor** stellt sicher, dass `CommandInfo`-Instanzen nur über die **statische `Create`-Methode** erzeugt werden können. Eine typische Implementation des Factory-Patterns.

Create wertet das `args`-Array aus:
- Wenn das Array **leer** ist, geben wir eine spezielle `None`-Instanz zurück.
- Bei **unvollständigen oder ungültigen Argumenten** geben wir `Invalid` zurück.
- Nur bei **gültigen Argumenten** erstellen wir eine `Valid`-Instanz mit den übergebenen Werten.

Das entspricht einer **abgewandelten Form des Null-Objekt-Patterns**, welches von der Rückgabe von Nullreferenzen abrät. Das vermeidet typische NullReferenceExceptions im aufrufenden Code und verbessert Lesbarkeit, Stabilität und Testbarkeit. Für diese Nullobjekte haben wir die Command-Enum noch erweitert.

---

### Create-Methode
Die `Create`-Methode erzeugt also aus dem `args`-Array eine passende `CommandInfo`-Instanz.

Zuerst prüfen wir, ob das `args`-Array **leer** ist.  
Falls ja, geben wir `None` zurück. 

Dann verwenden wir einen **try-Block** – falls beim Verarbeiten eine **Exception** auftritt, geben wir `Invalid` zurück und zeigen die **Fehlermeldung** an.

Die Auswertung läuft wie folgt:

- **Erstes Argument**: Wird mit `Enum.Parse<Command>(args[0], true)` in einen `Command` umgewandelt (Das true hier drückt bei falscher Groß-Klein-Schreibung ein Auge zu).
- **Zweites Argument**: Wird als **Dateipfad** interpretiert und gleich als Text eingelesen.
- **Ab dem dritten Argument**: Prüfen wir, ob die Einträge gültige **ISO-Sprachcodes** sind (z. B. `en`, `fr`). Gültige Codes sammeln wir im `LanguageCodes`-Feld.

Hier kommt **LINQ** ins Spiel – die mächtige **Datenabfragesprache** von .NET.  
Brechen wir es kurz herunter:

- `Skip(2)` bedeutet, dass die ersten beiden Einträge im Array ignoriert werden.  
- Das anschließende `Where` prüft jeden der verbleibenden Strings, ob unter den `CultureInfo`-Objekten von .NET eines dabei ist, dessen **zweibuchstabiger Sprachcode** (`TwoLetterISOLanguageName`) dem aktuellen String entspricht.  
- `Distinct()` stellt sicher, dass **keine doppelten Werte** in der finalen Liste auftauchen.

Diese gefilterten Sprachcodes sowie Kommando und InputText werden dann dem **Konstruktor der `CommandInfo`-Klasse** übergeben.  
Die erzeugte Instanz wird schließlich zurückgegeben.

Diese LINQ-Konstrukte wirken am Anfang vielleicht etwas **einschüchternd** – aber keine Sorge: Man gewöhnt sich schnell daran.  
Und im nächsten Kapitel gibt's noch etwas mehr davon!

Diese Factory-Methode liefert also letztlich:
- eine **valide Instanz**
- `None` (bei leerem Array)
- oder `Invalid` (bei fehlerhaften Argumenten oder Exceptions)

Ach - und wo wir schon bei den Entwurfsmustern - den Patterns - sind: die Create-Methode ist ein Vertreter nicht nur des Factory- sondern auch des Builder-Patterns: Wenn die Konstruktion eines Objekts komplex ist, lagere sie in eine eigene Methode aus, um für den Aufrufer die Konstruktion zu vereinfachen.

Ins Exception Handling sehen wir gleich noch genauer rein...


