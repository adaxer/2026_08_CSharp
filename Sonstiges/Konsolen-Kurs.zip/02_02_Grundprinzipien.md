## Zwei wichtige Prinzipien vorab  
In Konsolenanwendungen findet sich das wichtige Grundprinzip EVA und der Einsatz von Standardkanälen. 

---

### EVA Grundprinzip
Das EVA-Prinzip ist das Fundament jedes Programms, egal ob es sich um eine Konsolenanwendung, eine Web-App oder eine komplexe Business-Software handelt.
Es steht für Eingabe - Verarbeitung - Ausgabe und beschreibt den grundlegenden Ablauf eines jeden Computerprogramms.  

1. Eingabe (E):  
   Das Programm nimmt Daten vom Benutzer oder von einer anderen Quelle entgegen.  
   Beispiele: Tastatur, Dateien, API-Anfragen, Sensorwerte. In Konsolenanwendungen kommen all diese Quellen vor. 

2. Verarbeitung (V):  
   Die eingelesenen Daten werden bearbeitet, berechnet oder logisch ausgewertet.  
   Hier findet die eigentliche Programmlogik statt, also z.B. Berechnen, Vergleichen, Konvertieren usw.  

3. Ausgabe (A):  
   Die Ergebnisse der Verarbeitung werden ausgegeben.  
   Dies kann der Bildschirm, Dateien oder ein Netzwerk sein.  

Weil eine Konsolenanwendung im Allgemeinen auf ein konkretes Thema fokussiert ist, zeigt sich das EVA-Prinzip hier besonders deutlich. 

---

### Standardkanäle für EVA: stdin, stdout und stderr
`stdin`, `stdout` und `stderr` sind Standard-Streams zur Ein- und Ausgabe in Desktop-Betriebssystemen, angewandt besonders in Konsolenanwendungen, Skripten und Backend-Services. Beispiele für Konsolenanwendungen: 

1. `stdin` (Standard Input): Einlesen von Benutzereingaben   
  - Direkte Eingabe: `Console.ReadLine()`
  - Pipes und Umleitungen: `cat input.txt | dotnet run`
2. `stdout` (Standard Output): Normale Programmausgaben    
  - Konsolenanwendungen: `Console.WriteLine()`
  - Pipes und Umleitungen: `dotnet run > output.txt`
3. `stderr` (Standard Error): Fehlermeldungen
  - `Console.Error.WriteLine()`
  - `dotnet run 2> errors.txt`

Nun aber los: Im nächsten Abschnitt gehts um die logische Struktur und den typischen Inhalt einer Konsolenanwendung.