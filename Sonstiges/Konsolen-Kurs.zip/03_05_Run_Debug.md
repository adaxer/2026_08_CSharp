## Start und Debugging

Unser `LocalizeHelper`-Programm liest beim Start die **Kommandozeilenargumente** ein und erzeugt daraus eine Instanz von `CommandInfo`.  
In `Program.cs` rufen wir dazu die Methode `CommandInfo.Create(args)` auf.

Je nachdem, ob die Argumente **korrekt**, **inkorrekt** oder **gar nicht vorhanden** sind, erhalten wir eine passende `CommandInfo`-Instanz.  
Diese übergeben wir anschließend an die jeweils zuständige Methode.  

Das geschieht über eine `switch`-Expression, die abhängig vom `Command` eine der Methoden `MakeCsv()`, `MakeResx()`, `ShowMenu()` oder `ShowUsage()` aufruft. 
Diese Methoden haben wir bereits angelegt – sie enthalten allerdings nur eine kleine Info als Ausgabe.
Der Unterstrich ist übrigens der Fallback der Switch Expression, Er wird auch Discard-Operator genannt Und fängt die Fälle ab, die vorher nicht erfasst wurden.  

---

### Ausführung und Debugging

Führen wir unser Programm über das Terminal mit `dotnet run` aus,  
wird es kompiliert und gestartet – beendet sich jedoch direkt wieder, da aktuell keine Ausgabe erfolgt.

Probieren wir’s erneut und übergeben diesmal Testargumente, z. B.:  `dotnet run a b c`

Nun bekommen wir eine Fehlermeldung:

> "Requested value 'a' was not found."

---

### Debugging mit launch.json

Um die Fehlermeldung besser zu verstehen, sollten wir das Programm im **Debugger von Visual Studio Code** ausführen.

Dazu richten wir eine `launch.json` ein – Visual Studio Code schlägt dabei bereits passende Konfigurationen vor.  
Wir wählen `.NET: Launch C# project`, und füllen die Felder aus. Wichtig: `"type": "coreclr"`, `"request": "launch"`  
und `"program": "Pfad zur DLL! des Programs"`.

Außerdem ergänzen wir einen Eintrag für `args`, z. B.:
```json
"args": [ "a" "b" "c" ]
```

Nun können wir in den Debug-Tab wechseln und das Programm über den grünen Startpfeil starten.

### Breakpoint setzen und untersuchen
Vor dem Start setzen wir einen Breakpoint, z. B. in Program.cs direkt nach dem Aufruf von CommandInfo.Create().

Beim Ausführen hält das Programm an dieser Stelle an.
Wir sehen im Variablenfenster, hier unter Locals, dass das args-Array die Werte a b c enthält. Durch klicken auf die rechte Maustaste können wir Werte auch ändern. Darunter im Watch Fenster können wir beliebige Ausdrücke eingeben, die wir überwachen wollen, z.B. `Enum.Parse<Command>("1")` oder `Enum.Parse<Command>("ResXToCsv")`. Interessanterweise ergibt beides das gleiche Ergebnis. Das liegt daran, dass Enums intern in Zahlenwerten abgelegt werden.

Mit F10 können wir im Programmablauf die nächste Zeile ausführen. Mit F11 folgen wir Schritt für Schritt, Können also auch in andere Methoden hineinspringen.
Dabei sehen wir: Es gibt Argumente, also wird keine None-Instanz zurückgegeben.
Aber beim Parsen des Kommandos tritt ein Fehler auf – genau hier entsteht die oben gesehene Fehlermeldung.

So viel zum Debugging von Konsolenanwendungen mit Visual Studio Code. Doch kommen wir nun wie versprochen zum Behandeln von Exceptions.