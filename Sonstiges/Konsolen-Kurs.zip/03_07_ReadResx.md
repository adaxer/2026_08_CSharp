
## XML einlesen

Nun ist es an der Zeit, die tatsächliche Funktionalität unserer Konsolenapplikation in den Fokus zu nehmen. Die `Main`-Methode ruft bei korrekt übergebenen Parametern für `resx-to-csv` die Methode `MakeCsv` auf und übergibt ihr das `CommandInfo`-Objekt. Die restlichen Kommandos machen wir später. Wir können wir darauf verlassen, dass wir ein korrektes `CommandInfo`-Objekt haben. Das heißt: Wir wissen, dass die übergebene Datei Text enthielt, wir haben mindestens eine Zielsprache, und das Kommando ist `resx-to-csv`.

Beim Debugging hilft es, wenn wir passende Parameter in die `launch.json` eintragen, z. B.:
```json
"args": ["ResxToCsv", "Demo.de.resx", "en", "fr"]
```

Aus dem Kapitel zur Struktur wissen wir auch, wie man Dateien automatisch ins Ausgabeverzeichnis kopiert. Das machen wir hier mit unseren Testdateien (`Demo.de.resx` und der CSV-Datei mit deutschem Inhalt). Die `.resx`-Datei erfordert etwas mehr Aufwand, da MSBuild sie sonst als Ressourcen behandelt.

Ein `dotnet build` hilft uns, zu prüfen, ob alles korrekt eingebunden ist.

---

### Fehlerbehandlung und XML lesen

Die Methode `MakeCsv` schützen wir durch einen `try-catch`-Block. Warum nochmal? Der vorherige Block war in der `Create`-Methode, die zu diesem Zeitpunkt bereits abgeschlossen ist. Auch beim Einlesen des XML und Konvertieren in CSV kann etwas schieflaufen. In diesem Fall fangen wir die Exception ab, informieren die Anwender und beenden das Programm.

Innerhalb des `try`-Blocks erzeugen wir nun aus dem `InputText` des `CommandInfo`-Objekts (der ja die `.resx`-Datei enthält) eine Liste von XML-Elementen. Hierfür verwenden wir `System.Xml.Linq`. Damit lassen sich XML-Elemente per LINQ sehr bequem einlesen, transformieren, sortieren – eben alles, was man mit Aufzählungen so macht.

Startpunkt ist `XElement.Load`, das jedoch keinen String direkt akzeptiert, sondern einen `StringReader`, dem wir den Text übergeben. Daraus füllen wir unsere Liste mit den zu übersetzenden Texten – per LINQ:

```csharp
var elements = from element in xml.Elements("data")
               where element.Attribute("name") != null && element.Element("value") != null
               select new KeyValuePair<string, string>(
                   element.Attribute("name")!.Value,
                   element.Element("value")!.Value
               );
```

xml.Elements bezieht sich auf alle Unterelemente des XML-Root-Objekts. Wir sehen es hier in der Datei: Unter dem typischen XML-Header befindet sich ein Root-Element mit dem Namen root. Dort sind einige sogenannte resheader-Elemente und danach unsere data-Elemente.

Jedes dieser data-Elemente hat ein Attribut name und ein Unterelement value.

Mit from element in xml.Elements("data") ignorieren wir die resheader-Elemente und greifen nur auf die data-Elemente zu.

Der where-Teil sichert uns gegen fehlerhafte Daten ab – also: Wenn eines der data-Elemente kein name-Attribut oder kein value-Unterelement besitzt, schließen wir es aus.

Nun zur langen select-Zeile: Ein KeyValuePair<string, string> ist ein praktisches Objekt, bestehend aus einem Schlüssel und einem Wert – beides Strings. Genau diese beiden Strings erwartet der Konstruktor von KeyValuePair.

Wir übergeben also das name-Attribut des Elements als Key. Der !-Operator teilt dem Compiler mit, dass dieser Wert garantiert nicht null ist – das haben wir vorher im where ausgeschlossen. Dasselbe machen wir mit dem value-Element.

---

### LINQ-Ausführung prüfen

Zeit, das zu testen: Wir setzen einen Breakpoint nach dem Einlesen des XML. Der Haltepunkt wird erreicht. Im Debugger sehen wir, dass das `CommandInfo`-Objekt korrekt befüllt ist: Kommando gesetzt, `InputText` enthält XML, `LanguageCodes` enthält `"en"` und `"fr"`.

Wenn wir das XML-Element einlesen, sehen wir: Es ist gefüllt und zeigt auch gleich das Root-Element an.

Und wenn wir nun die data-Elemente einlesen, sehen wir eine IEnumerable von KeyValuePairs – und in der Ergebnisansicht sehen wir unsere Paare: "Login" / "Anmelden", "Logout" / "Abmelden" und so weiter.

Ein kleiner Stolperstein: Diese LINQ-Abfrage ist noch nicht wirklich ausgeführt worden, sondern nur definiert. In dem Moment, wo wir zum ersten Mal auf result zugreifen – also z. B. in der Ergebnisansicht –, wird die LINQ-Abfrage tatsächlich ausgeführt. Das nennt man "deferred execution".
