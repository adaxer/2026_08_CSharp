## Usage anzeigen

Falls beim Parsen der `CommandInfo` ein Fehler aufgetreten ist, wird die Methode `ShowUsage` aufgerufen.  
Wir definieren dort einfach einen String, der in mehreren Zeilen eine kurze Erläuterung mit Beispielen für das Programm darstellt, und geben diesen auf der Konsole aus.

Das könnte zum Beispiel so aussehen:

```csharp
var usage = """
Verwendung:
  LocalizeHelper resx-to-csv <Pfad-zur-RESX-Datei> <Sprachcode1> [Sprachcode2] ...
  LocalizeHelper csv-to-resx <Pfad-zur-CSV-Datei>

Beispiele:
  LocalizeHelper resx-to-csv Demo.de.resx en fr
  LocalizeHelper csv-to-resx Demo.translation.csv
""";

Console.WriteLine(usage);

Wenn wir unser Programm starten und dabei irgendwelche Argumente übergeben, die es nicht kennt – oder eine Datei angeben, die nicht existiert –,  
dann sehen wir, dass tatsächlich die `Usage` ausgegeben wird.

