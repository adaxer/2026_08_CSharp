## Projekt anlegen
Unser Projekt heißt **LocalizeHelper**. Da es später mehrere Methoden enthalten wird, wählen wir – wie im Grundlagenkapitel gelernt – die Struktur **ohne Top-Level-Statements**. Um es anzulegen, verwenden wir wieder die **Kommandozeile**.  

Im Terminal sehen wir, dass wir uns im Verzeichnis `Projekte\LocalizeHelper` befinden. Unser Projekt soll ebenfalls **LocalizeHelper** heißen. Also geben wir ein:  

`dotnet new console -n LocalizeHelper`

Doch Moment – wird das Projekt jetzt in einem **neuen Unterverzeichnis** `LocalizeHelper` erstellt? Oder – wie eigentlich gewünscht – im **aktuellen Verzeichnis**?

Das sollten wir vorher klären...

Rufen wir `dotnet new console -n LocalizeHelper --help` auf, zeigt uns das CLI alle Optionen.

Eine davon ist `--dry-run`. Diese führt das Kommando **testweise aus**, ohne tatsächlich Dateien zu erstellen – es zeigt nur, welche Dateien generiert würden.

Probieren wir’s also mit:  

`dotnet new console -n LocalizeHelper --dry-run`

Laut Ausgabe würden eine Datei `LocalizeHelper.csproj` und eine `Program.cs`-Datei erzeugt. 

Doch Vorsicht: Das ist **irreführend**. Führen wir das Kommando **ohne `--dry-run`** im Verzeichnis `LocalizeHelper` aus, legt das Tool ein **Unterverzeichnis `LocalizeHelper`** an – in dem eine sln-Datei und das eigentliche Projekt in einem Unter-Unterverzeichnis landen, alle mit demselben Name.

Die `--dry-run`-Ausgabe ist hier also **nicht korrekt**.

Die Lösung: Zusätzlich zum Name geben wir den aktuellen Ordner als Zielverzeichnis an, also:

`dotnet new console -n LocalizeHelper -o . --use-program-main`

Damit wird das Projekt **direkt im aktuellen Verzeichnis** angelegt – ganz ohne zusätzliche Unterordner. In der Datei-Pane von Visual Studio Code können wir uns davon überzeugen.