## Konsolenanwendung aus anderem Programm aufrufen
Oft möchte man aus einem anderen Programm aus eine Konsolen Applikation aufrufen. Das ist möglich über die Process-Api von .Net. Erarbeiten wir uns, wie das geht.

### Testprojekt zur Ausführung vorbereiten

Wir haben unsere `LocalizeHelper`-App in ein Verzeichnis Praxis verschoben. Die Solution-Datei. löschen wir. Wir wollen nämlich dieses Projekt und das neue, die Testapplikation, beide als Projekte in die Solution einbauen. Die sln-Datei muss dann ins übergeordnete Verzeichnis.
Also `dotnet new sln -n Praxis -o .` und `dotnet sln add LocalizeHelper/LocalizeHelper.csproj`

Zu dieser fügen wir nun ein neues Projekt hinzu. Wir erzeugen es erstmal über:

`dotnet new console -n LocalizableApp -o LocalizableApp` und fügen es unserer Solution hinzu mit `dotnet sln add LocalizableApp/LocalizableApp.csproj`

Dann wird das Projekt automatisch mitgeladen, wenn man die Solution von LocalizeHelper lädt.

Wir überzeugen uns im Dateisystem davon, dass das so geklappt hat:
Hier ist das Projekt im Unterverzeichnis, wie geplant – und wir sehen es auch in der Solution-Datei.

---

### Projekt mit Leben füllen
Füllen wir unseren Test-Client mit Leben. 
Übrigens ist es offensichtlich eine Top Level Statement Anwendung? Das stört uns hier aber nicht.

Zunächst setzen wir einige Pfade.

Wir brauchen den Pfad zum LocalizeHelper, weil wir ihn ja von der Testapplikation aus aufrufen.

Diesen bekommen wir über Path.GetFullPath(...) – eine sehr praktische Methode, weil man damit auch Pfade erreichen kann, die oberhalb des aktuellen Pfades liegen oder parallel dazu.

Wir sehen, dass wir tatsächlich vier Verzeichnisse nach oben navigieren müssen – mit den ..\\ und doppelten Backslashes.

Das Zielverzeichnis ist das Build-Verzeichnis des Programms.
Im Dateisystem kann man das nachvollziehen:

Wir starten im net9.0-Verzeichnis von LocalizableApp,
gehen viermal nach oben – und sind dann im Hauptverzeichnis Praxis.
Von dort aus gehen wir ins Build-Verzeichnis von LocalizeHelper.

Dort liegen das Programm und die Demodateien.

Prozess starten
Wir kopieren unsere Demo.de.resx-Datei zum Testprogramm.

Dann definieren wir eine Variable, die zum Pfad der lauffähigen Version von LocalizeHelper führt,
und legen eine ProcessStartInfo an.

Diese nimmt auf:

- den Dateinamen des Prozesses, also LocalizeHelper.dll
- das sogenannte WorkingDirectory, also das Verzeichnis, das LocalizeHelper als aktuelles Verzeichnis ansehen wird
- und wir reichen einfach die Argumente weiter, z. B. ResxToCsv Demo.de.resx en fr

Dann starten wir den Prozess. Mit Warten darauf, dass er sich beendet. Hierbei verwenden wir die Async-Variante. Der Compiler Wird das beim Build automatisch so einrichten, dass die Main Methode ein Async Task ist.

Wir können das Programm **nicht direkt aus Visual Studio Code** heraus starten.  
Vorher haben wir ja gesehen, dass die Konsole nicht vollständig ist und zu Exceptions führen würde –  
wenn man es nicht in der `launch.json` auf eine **externe Konsole** umstellt.

Aber wir müssen hier nicht debuggen – ich habe den Code getestet.

---

### Ausführung über das Terminal

Navigieren wir einfach im Dateisystem in das Verzeichnis der Debug-Version von `LocalizableApp`,  
und lassen uns per Rechtsklick ein Terminal öffnen.

Wenn wir dort eingeben:

`LocalizeHelper resx-to-csv Demo.de.resx en fr`, dann sehen wir, dass unser LocalizeHelper seinen Job macht – und die CSV-Datei erzeugt.

Rufen wir das Programm nochmal auf – mit garantiert falschen Argumenten:

Ja, hier ist die Usage, wie erwartet.

Und nun komplett ohne Argumente?

Tatsächlich erscheint das interaktive Menü. Wir wissen, dass es funktioniert. Also beenden wir es gleich.

---

### Weitere Möglichkeiten mit ProcessStartInfo
Die ProcessStartInfo-Klasse hat noch ein paar Tricks mehr auf Lager:

Man kann den Prozess so anlegen,
dass Eingabe, Ausgabe sowie Fehlerkanal umleitbar sind.

Damit kann man z. B. die Ausgabe in einem eigenen Fenster darstellen.

Die Dokumentation zur ProcessStartInfo-Klasse enthält dazu einige Beispiele.

Weiter geht's mit dem Deployment, der Verteilung von .Net-Konsolenanwendungen
