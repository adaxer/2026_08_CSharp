## Auf anderen Plattformen
Nun sehen wir uns an, wie wir unsere Konsolen Applikationen auf Linux und auf Mac OS ausführen können. Hierzu muss auf den anderen Plattformen dot net. installiert werden. Und eventuell wollen Sie Visual Studio Code auf der anderen Plattform nutzen. Wie das geht? Hab ich in der Readme-Datei zusammengefasst. 
Nun zu Linux.

---

### Ausführen unter Linux (Ubuntu)

Also probieren wir es auf den anderen Plattformen aus.  
Ich habe hier einen virtuellen Computer in Hyper-V, auf dem Ubuntu 22.04 installiert ist.

Wenn ich auf der Windows-Maschine das Publish-Skript aufrufe – für Linux also:
`dotnet publish -c Release -r linux-x64 --self-contained false`  
und dann in das Publish-Verzeichnis gehe – hier ist es –, dann sehe ich die Dateien:

- das Programm selbst (in etwa derselben Größe wie die Windows-Variante),
- die `.pdb`-Datei mit den Debuginformationen,
- und unsere beiden Demodateien.

Dieses Verzeichnis habe ich auf die Linux-Maschine kopiert, ins Verzeichnis `/dev/localizeHelper`.

In diesem Verzeichnis muss ich nun ein Terminal öffnen, um das Programm **ausführbar*Hallo.* zu machen.  
Das ist ein zusätzlicher Schritt auf Linux – damit das Programm auch tatsächlich die Rechte hat, ausgeführt zu werden.

Wir gehen also im Terminal in das Verzeichnis und geben ein:

`chmod +x LocalizeHelper`

Jetzt können wir das Programm von der Konsole starten. Machen wir ein ResxToCsv mit Demo.de.resx und EN FR, siehe da, läuft wie erwartet...

Diese Version ist übrigens **framework-dependent** – also muss auf dem System .NET 9 installiert sein. Auch Visual Studio Code könnten Sie installieren. Siehe Readme-Datei.

---

### Arbeiten mit dem .NET CLI unter Linux

Ich zeige jetzt noch schnell, wie man mit dem .NET CLI auf Linux arbeitet.

Zunächst holen wir uns das Git-Repository:

`git clone <Adresse>`

Funktioniert genauso wie auf Windows.

Wechseln wir ins Verzeichnis, und dort in unser Praxis-Unterverzeichnis `LocalizeHelper`.

Hier verwenden wir den `dotnet publish`-Befehl mit `--self-contained true`, stellen zusätzlich  SingleFile und Trimmed en:

`dotnet publish -c Release -r linux-x64 --self-contained true /p:PublishSingleFile=true /p:PublishTrimmed=true`

Navigieren wir jetzt ins Publish-Verzeichnis:  
`bin/Release/net9.0/linux-x64/publish`

Lassen wir uns die Dateien anzeigen mit:

`ls -l`

Dann sehen wir, dass die autark lauffähige Version ca. 17 MB hat.  
Sie enthält nur den Teil von .NET, der im Programm wirklich aufgerufen wird – das erledigt das Trimming.

Machen wir das Programm wieder lauffähig:

`chmod +x LocalizeHelper`

Und starten es:

`./LocalizeHelper`

Wir sehen: Das Menü kommt. An der Stelle können wir abbrechen.

---

### Ausführen unter macOS

Zu guter Letzt: macOS.

Ich öffne hier mein Terminal am Mac.  
Ich habe .NET bereits auf Version 9 aktualisiert und das Projekt von GitHub geklont.  
Im Verzeichnis von `LocalizeHelper` führe ich erneut ein `publish` aus.

Was hatten wir denn noch nicht?  
**AOT** könnten wir probieren.

Nehmen wir hier die Kurzform:

`dotnet publish -p:PublishAot=true`

Alle anderen Parameter brauchen wir nicht anzugeben – sie sind durch Default-Werte gesetzt.

---

Navigieren wir ins Publish-Verzeichnis und lassen uns den Inhalt ausgeben:

`cd bin/Release/net9.0/osx-x64/publish`  
`ls -l`

Wir messen:  
Das Programm hat **nicht einmal 9 MB** – ein Ergebnis der starken Kompression durch `PublishAot`.

Und wir können das Programm direkt starten:

`./LocalizeHelper`

Einfach mal mit Fantasie-Parametern – um die `Usage` zu bekommen.

Und dann mit der Umwandlung `csv-to-resx` – hat funktioniert!

