## Übung: Interaktives Menü mit Auswahl
Auf zur nächsten Übung: 
Wir wollen ShowMenu nutzen, um in einer Endlosschleife die Nutzereingaben anzuzeigen.

- Wenn Sie es komplett selbst machen wollen: Respekt! :-) 
  - Erzeugen Sie eine neue **Konsolenanwendung**, zum Beispiel mit dem Namen **ShowMenu**. Achten Sie auf die launch.json, wie unten erwähnt!
- Wenn Sie nur die Schleife programmieren möchten:
  - Das Projekt **ShowMenu** kommt Ihnen bei der Aufgabe auf halbem Weg entgegen und versteckt den Inhalt der Schleife weiter unten ;-).

**Achtung**, hier kommt eine Eigenheit von VSCode zum tragen. Die Anwendung läuft nicht direkt aus VSCode heraus, weil es kein "vollständiges" Terminal hat. Man kann aber ein vollständiges Terminal verwenden, wenn man das in launch.json einstellt. Die launch.json sieht dann so aus:

```json
{
    "version": "0.2.0",
    "configurations": [{
        "name": "Debug ShowMenu",
        "type": "coreclr",
        "request": "launch",
        "program": "${workspaceFolder}/bin/Debug/net9.0/ShowMenu.dll",
        "console": "externalTerminal",
        "args": []
      }]
}
```
---

1. Kopieren Sie die Methode `ShowMenu()` aus dem **ConsoleClass**-Projekt in dieses neue Projekt.

2. Fügen Sie dann **zwei Zeilen unterhalb des Menüs** eine Ausgabe ein, die die jeweilige Eingabe anzeigt.  
Wenn z. B. **"L"** für **Laden** gedrückt wurde, soll erscheinen: `Ihre Wahl: L - Laden`

3. Wenn **"X"** für **Beenden** gedrückt wurde, soll das Programm beendet werden.

4. Eine Taste, die nicht im Menü vorkommt, soll per "Falsche Eingabe" quittiert werden.

### Hinweise

- Sie könnten das `string[] menuItems`-Array als **statische globale Variable** definieren, damit es ausserhalb der Methode `ShowMenu()` erreichbar ist, ebenso die Cursorposition zur Ausgabe der jeweiligen Auswahl. 
- Verwenden Sie in der **Endlos-Schleife** `Console.ReadKey()`. 
  - Der Buchstabe ist per `Console.ReadKey(true).Key.ToString()` zu ermitteln. 
- Suchen Sie den gedrückten Key im Menüarray. (per `menuItems.FirstOrDefault(i=>i.StartsWith(key))`). 
  - Die String-Länge steht in der Property Length.  
- Setzen Sie den Cursor **zwei Zeilen unterhalb** des Menüs.
- Geben Sie dort zuerst einen längeren String mit Leerzeichen aus, um vorige längere Ausgaben zu löschen.
- Dann schreiben Sie die aktuelle Auswahl.


Diese Aufgabe ist schon etwas anspruchsvoller – aber Sie kriegen das hin!

Im nächsten Video zeige ich Ihnen wieder meine Lösung.
