## Übungsaufgabe: Argumente ausgeben

Zeit für eine erste Übungsaufgabe:  

Legen Sie ein neues C#-Konsolenprojekt an – zum Beispiel mit dem Namen **PrintArgs**.

Die Aufgabe besteht darin, die übergebenen Argumente auf der Konsole auszugeben – und, wenn Sie sich's zutrauen, diese alphabetisch zu sortieren.

Ich empfehle Ihnen, die Aufgabe umzusetzen. Das hilft, sich mit der Entwicklungsumgebung und dem Arbeiten mit **Visual Studio Code** vertraut zu machen.

Natürlich besteht keine Verpflichtung 😄 – vor allem, wenn Sie bereits viel mit .NET und C# gearbeitet haben.

Im nächsten Video zeige ich Ihnen meine Lösung.  
Also: Wenn Sie Lust haben, drücken Sie jetzt **Pause** – und legen Sie los!

