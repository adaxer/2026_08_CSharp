## Lösung: Argumente alphabetisch ausgeben

Wir sind im **Visual Studio Code** im Terminal und erzeugen ein neues Projekt:

`dotnet new console -n PrintArgs --use-program-main`

Dann navigieren wir ins Verzeichnis:

`cd PrintArgs`
Wir öffnen den Ordner in Visual Studio Code:

`code . -r`

Im Projekt sehen wir die Klasse Program mit der Einstiegsmethode Main, der die Argumente übergeben wurden.

`Console.WriteLine("Ich habe folgende Argumente erhalten – alphabetisch sortiert:");`

In einer foreach-Schleife sortieren wir die args mit args.Order() Und geben Sie per Console.WriteLine aus.

Mit Ctrl+Ö öffnen wir uns ein Terminal und starten das Programm mit z.B. dotnet run hans , 42 anton 

So haben wir alle übergebenen Argumente alphabetisch – LINQ sei Dank!