## Externe Libraries für Konsolen-Apps

Nun haben wir so einiges aus der Konsole mit .NET herausgeholt – und die dotnet-eigene Funktionalität ziemlich ausgereizt.

Dabei merkt man: Die Möglichkeiten von .NET greifen manchmal etwas kurz. Zum Beispiel bei der Auswertung der Argumente, um Kommandos und Optionen abzuleiten. Oder bei den grafischen Möglichkeiten der Konsole – Fortschrittsanzeige, Tabellen, Farben. Da geht natürlich noch mehr.

Das wird möglich durch **externe Libraries**, von denen ich hier einige Beispiele nennen möchte:

---

### CommandLineParser

Diese Library fokussiert sich darauf, Kommandos und Optionen aus Argumenten zu erzeugen.  
Ein Blick auf die GitHub-Seite zeigt:  
Man definiert eine Klasse `Options` mit Attributen wie `[Option('v', "verbose", HelpText = "Mehr Ausgabe ...")]`,  
und lässt den eingebauten Parser einfach `args` analysieren.

---

### Cocona

Cocona hat ein anderes Konzept.  
Man kann Kommandos direkt als Methoden definieren – versehen mit dem `[Command]`-Attribut.  
Die Argumente dieser Methoden werden automatisch zu Optionen, inkl. Namenszuordnung.  
Intern nutzt Cocona das `CommandApp`-Objekt, um alles zu starten.

---

### Spectre.Console

Spectre.Console hat sogar eine eigene Homepage – und bietet ungeheuer viele Funktionen.  
Auch hier lassen sich Kommandos und Optionen einfach definieren.

Die eigentliche Stärke liegt aber in der **grafischen Ausgabe**:
- Farben
- Spalten-Layout
- Tabellen
- Charts
- Fortschrittsanzeigen
- Animationen

Alles lässt sich deklarativ und trotzdem flexibel steuern – ideal für visuelle Konsolenanwendungen.

---

### CLIWrap

CLIWrap setzt dort an, wo die .NET-`Process`-API aufhört.

Wir haben ja vorher unsere Konsolenanwendung aus einem anderen Prozess gestartet – das ging, war aber recht umständlich.

Mit CLIWrap geht das deutlich eleganter – durch sogenannte *fluent APIs*.  
Man kann:
- den Prozess starten
- Argumente und Arbeitsverzeichnis übergeben
- synchron oder asynchron warten
- Ein- und Ausgabekanäle umleiten

Besonders spannend ist die sogenannte *Buffered Execution*:  
Man kann die Ausgabe-Streams zwischenspeichern und nach Beendigung des Prozesses weiterverwerten.

Dadurch lassen sich z. B. Pipelines aufbauen – ein Programm erzeugt eine Ausgabe, die direkt ins nächste Programm fließt.

---

### Fazit

In meinem kommenden **Intensivkurs zur Konsolenprogrammierung** werde ich auf diese Libraries näher eingehen.  
Damit können Sie Ihre Konsolenanwendungen **noch attraktiver und leistungsfähiger** gestalten.

Aber in diesem Kurs haben Sie bereits genug gesehen und gelernt.

Also – fassen wir ihn im nächsten Kapitel noch einmal zusammen.
