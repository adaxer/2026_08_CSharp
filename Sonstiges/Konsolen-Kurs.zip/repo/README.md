# Konsolenanwendungen mit C#

Dies ist das Repository für den **LinkedIn Learning** Kurs `[COURSENAME]`. Den gesamten Kurs finden Sie auf [LinkedIn Learning][lil-course-url].

![COURSENAME][lil-thumbnail-url] 


[COURSEDESCRIPTION]

## Anleitung

Dieses Repository enthält den Source-Code für den Kurs. Der komplette Code ist im Branch `main` enthalten. 

Die Projekte sind Unterordner der Ordner mit den Kapitelnummern im Titel. So ist z.B. das erste Projekt im Einführungskapitel im Ordner `/Kapitel1/HelloWorld` zu finden. 

Die Projekte enthalten immer den endgültigen Stand. Das typische Muster _b und _e (für "beginning" und "end") hat hier keine Anwendung, weil das Aufsetzen der Projekte kaum aufwendiger ist als das Laden eines git-Standes.


## Installation

Dieser Kurs verwendet .Net in der aktuellen Version und Visual Studio Code. Die Installation wird im Kurs ausführlich für Windows erläutert. Zur Installation auf den anderen beiden Plattformen hierzu eine Kurzanleitung
Linux:
1. Einige Abhängigkeiten und Tools:
sudo apt install -y wget apt-transport-https software-properties-common
wget https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
sudo dpkg -i packages-microsoft-prod.deb
2. .Net SDK
Sudo apt install –y dotnet-sdk-8.0
3. Testen
dotnet –-version
4. Vscode installieren
wget -q https://packages.microsoft.com/keys/microsoft.asc -O- | sudo apt-key add -
sudo add-apt-repository "deb [arch=amd64] https://packages.microsoft.com/repos/vscode stable main" 
sudo apt update
sudo apt install code
5. C#-Erweiterungen installieren


MacOS:
````
brew update 
brew install --cask dotnet-sdk
dotnet --version 
export PATH="$PATH:/usr/local/share/dotnet/dotnet/64“
````
VSCode von https://code.visualstudio.com/docs/setup/mac

### Autor

**Andreas Daxer**

Architekt, Trainer, Entwickler und Berater für Microsoft .Net

Sehen Sie sich andere Kurse des Autors auf [LinkedIn Learning](https://www.linkedin.com/learning/instructors/name_des_autors) an.

[0]: # (Replace these placeholder URLs with actual course URLs)
[lil-course-url]: https://www.linkedin.com
[lil-thumbnail-url]: https://media.licdn.com/dms/image/v2/D4E0DAQG0eDHsyOSqTA/learning-public-crop_675_1200/B4EZVdqqdwHUAY-/0/1741033220778?e=2147483647&v=beta&t=FxUDo6FA8W8CiFROwqfZKL_mzQhYx9loYLfjN-LNjgA

