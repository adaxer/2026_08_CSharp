## Abschluss

Gratuliere – Sie sind am Ende des Kurses angekommen!

Es gab viel zu lernen:  
Sie wissen jetzt, wie man .NET, Visual Studio Code und Erweiterungen installiert –  
und mit Visual Studio Code **Konsolenanwendungen schreibt und debuggt**.

Sie haben das **EVA-Prinzip** kennengelernt – Eingabe, Verarbeitung, Ausgabe –  
sowie die drei Kanäle: **Eingabe**, **Ausgabe**, **Fehlerausgabe**.

Sie verstehen die **Dateistruktur von .NET-Projekten**,  
und kennen die wichtigsten Methoden der `Console`-Klasse:  
Einlesen, Ausgeben, **Farben setzen**, **Cursor positionieren**.

In einem umfangreichen **Praxisbeispiel** haben Sie gelernt:

- XML und CSV-Daten zu **lesen und zu schreiben**
- ein interaktives **Menü zu programmieren**
- eine Konsolen-App aus **einer anderen Anwendung heraus zu starten**
- und wie man Konsolenanwendungen **verteilt** und auf **Windows**, **Linux** und **macOS** ausführt

---

### Wie geht’s weiter?

Mit **zusätzlichen Libraries** kann man die Funktionalität und grafische Attraktivität von Konsolenanwendungen weiter **ausbauen**:

- Eigene Libraries einbinden (per **Dependency Injection**)
- Zugriff auf **Datenbanken**
- Einbindung von **Logging**
- Abrufen von **Daten aus dem Internet**

Nutzen Sie die sehr gute **.NET-Dokumentation von Microsoft** – und bleiben Sie am Ball!

 Wenn Ihnen dieser Kurs gefallen hat: Der **weiterführende Kurs zu Konsolenanwendungen** ist schon in Vorbereitung.
