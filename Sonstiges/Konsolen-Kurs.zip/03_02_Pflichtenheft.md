## Pflichtenheft: Umsetzung planen
Im vorherigen Abschnitt haben wir die gewünschte Funktionalität festgelegt – das **Lastenheft**. Nun geht es um die Umsetzung, also das **Pflichtenheft**.

Unsere Konsolenanwendung soll zwei **Kommandos** unterstützen:
- `.resx`-Dateien in `.csv` umwandeln
- `.csv`-Dateien zurück in `.resx` konvertieren

Dazu müssen **Dateipfade** als Argumente übergeben werden. Außerdem können **Zielsprachen** angegeben werden.

Falls das Programm mit **falschen oder unvollständigen Argumenten** aufgerufen wird, soll eine **Usage-Anzeige** erscheinen – also ein Hilfetext mit den möglichen Kommandos, Optionen und Argumenten in der richtigen Reihenfolge.

Wird das Programm **ohne Argumente** gestartet, zeigen wir ein **Menü** an.

Es ist sinnvoll, dem Anwender **Zwischenstände und Endergebnisse** mitzuteilen.

Zum Schluss betrachten wir noch, **wie man das Tool aus einem anderen Programm heraus aufrufen kann**.

Beginnen wir damit, das Projekt anzulegen. Hier gibt es nämlich einige Spitzfindigkeiten.
