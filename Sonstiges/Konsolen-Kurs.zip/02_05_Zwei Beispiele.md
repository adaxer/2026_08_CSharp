### Interaktives Menü
Hier verwenden wir die Methoden `Console.Clear`, `Console.SetCursorPosition` und `Console.Write`  
im Zusammenhang mit den Eigenschaften `Console.WindowHeight` und `Console.WindowWidth`,  
um den Inhalt der Konsole zu löschen und anschließend **mittig ein Menü anzuzeigen**.  

Im `string[] menuItems` sind die verfügbaren Befehle als Zeichenketten definiert.  

Anschließend berechnen wir die Position des Menüs so, dass es **horizontal und vertikal zentriert** dargestellt wird.  

In der Schleife setzen wir jeweils die Cursorposition an die richtige Stelle und geben die Menüoptionen aus.  

Im nächsten Kapitel werden wir ein solches Menü **in der Praxis einsetzen**.

---

### Console.Write
#### FFmpeg
Kennen Sie FFmpeg? Mit dem Konsolenprogramm `FFmpeg` kann man Videos schneiden, zusammenfügen, konvertieren, Audiospuren extrahieren und vieles mehr. Es ist ein Konsolenprogramm, dessen Ausgabe durchaus interessant ist. Zunächst gibt es zeilenweise Text aus und schreibt laufend den aktuellen Status in die unterste Zeile, vermeidet dabei aber Zeilenumbrüche.  

Dieses Verhalten können wir mit unserer Konsolen-Applikation nachbilden. Schauen wir also, was es hier zu lernen gibt.  

Wir haben FFmpeg in Aktion gesehen und werden dann in der Konsolen-Applikation nachvollziehen,  

- wie man ein Programm asynchron macht,  
- wie man eine Wartezeit einbaut, damit die Konsolenausgabe sich in nachverfolgbarem Tempo ändert,  
- wie man String-Padding und Interpolation nutzt, also Strings formatiert,  
- und wie man Ausgaben auf eine Zeile beschränkt.  

---

#### Umsetzung in unserer Konsolenanwendung  
In unserem Konsolenprogramm haben wir die `Main`-Methode als `Task` deklariert, damit sie `async` genutzt werden kann.  

##### Warum `async Main`?  
Indem wir `Main` asynchron machen, können wir `await` direkt verwenden,  
ohne dabei blockierende oder umständliche Konstruktionen nutzen zu müssen. Dies führt unter anderem zu:  

- **Besserer Lesbarkeit** des Codes  
- **Nicht blockierendem Verhalten**, sodass die Anwendung Resourcen schont

(Dies ist natürlich eine sehr oberflächliche Erklärung, dieses Thema ist bereits alleiniger Inhalt etlicher Kurse)

Der Cursor stört optisch etwas, verstecken wir ihn einfach, dann simulieren wir mit "normalen" Zeilen den ersten Teil der FFmpeg-Ausgabe.  

Dann starten wir eine Schleife von `1` bis `100`. Innerhalb dieser Schleife:  

- Nutzen wir `await Task.Delay(200);`, um die Ausgabe etwas zu bremsen.  
- Geben einen Output-String aus, der rechtsbündig formatiert ist.  
- Verwenden dabei String-Interpolation, um dynamisch Inhalte in den String einzufügen.  

Die String-Interpolation ermöglicht es, Text mit laufendem C#-Code oder abgefragten  
C#-Informationen zu kombinieren.  

Am Ende jedes Durchlaufs geben wir den Text auf der Konsole aus.  

Wenn wir das Programm ausführen, sehen wir die "normalen" Zeilen und schließlich die 
letzte Zeile, wo die Ausgabe immer wieder erneuert wird.

Hier könnte nun der (natürlich) sinnvollere Inhalt Ihres Projekts stehen. Und eine lang laufende Aufgabe ausführen, aber dabei den Anwendern eine angenehme User Experience bieten.

---

Damit haben wir genug Voraussetzungen, um größere und praxisnähere Aufgaben anzugehen. Auf geht's zum Projekt Localize-Helper