## Lösung zur Übung: ShowMenu

Wir haben hier also das Projekt **ShowMenu**.

Die `Main`-Methode enthält die **Endlosschleife**.  
Wir haben eine Methode `Print`, die die Ausgabe etwas erleichtert:  
Sie setzt die Cursorposition an die passende Stelle, schreibt dann die Message aus und setzt die Cursorposition "wieder aus dem Weg", sozusagen.

Die Methode `ShowMenu` ist wie im früheren Projekt – nur dass das Array `menuItems` ausgelagert wurde in eine **statische Variable**.

Weiterhin haben wir zwei Koordinaten, die uns beim Setzen des Cursors helfen:  
Der Startpunkt wurde direkt aus der `ShowMenu`-Methode in eine statische Variable verschoben.  
Die Y-Koordinate der Ausgabe entspricht der halben Höhe des Konsolenfensters, plus der Zahl der Menüeinträge, halbiert plus 2.  
So landet die Ausgabe zwei Zeilen unter dem letzten Menüeintrag.

In der Endlosschleife lesen wir immer per `Console.ReadKey` die Tasteneingabe ein.  
Wir machen daraus einen String, der automatisch großgeschrieben ist (`Key.ToString()` liefert z. B. `"L"`).  
Wenn es kein Buchstabe ist, kommt einfach ein anderer String raus, der im Menü nicht vorkommt – das entspricht einer **falschen Eingabe**.

Mit der LINQ-Konstruktion FirstOrDefault ermitteln wir dann die tatsächliche Auswahl:  
Wir suchen das erste `menuItem`, das mit diesem Buchstaben beginnt. Wenn keins gefunden wird, kommt `null` zurück, und wir nehmen per sogenanntem NullCoalescing Operator `"Falsche Eingabe"` als Ausgabestring.

Dann geben wir an der berechneten Cursorposition eine Reihe Leerzeichen aus – abhängig von der maximalen Länge eines Menüeintrags oder dem Text `"Falsche Eingabe"`.

Dann geben wir aus, was die Eingabe war – über die **String-Interpolation**, die wir ja schon kennen.

Wir setzen dann das Flag `isDone`, falls `"X"` gedrückt wurde – dann wird die Schleife und damit das Programm beendet.

---

### Hinweise zur `launch.json`

Die Datei enthält den Parameter `"console"`, der auf `"externalTerminal"` gesetzt ist.  
Das ermöglicht es uns, **in Visual Studio Code zu debuggen**, was die Entwicklung natürlich erleichtert.

Die `launch.json` haben wir über das Hinzufügen einer neuen Konfiguration erzeugt.  
Sie wird im Unterverzeichnis `.vscode` des Projekts gespeichert, hier sehen wirs im Explorer.

Im Debug-Fenster wählen wir sie aus, indem wir die Konfiguration anklicken und dann den **grünen Startpfeil** verwenden.
