### CSV-Zeilen erzeugen

Unsere Beispiel-CSV (`Demo.original.csv`) zeigt, was wir erzeugen müssen: Eine Überschrift mit vier Spalten – `Key`, `DE`, `EN`, `FR`. In jeder Zeile steht der `Key`, der deutsche Originaltext und zwei leere Felder für die Zielsprachen.

Damit das CSV kompatibel zu möglichst vielen Tools bleibt, sind alle Texte in Anführungszeichen eingeschlossen, und die Spalten durch Kommas getrennt.

Dafür bietet sich eine Liste von `string` an. Dabei müssen wir sorgfältig vorgehen – es kann ja sein, dass nur eine Zielsprache oder mehr als zwei angegeben wurden.

Also erzeugen wir uns den Teil der Überschrift, der zu den Zielsprachen gehört – per string.Join(",", ...) – und interpolieren jeden Sprachcode in Anführungszeichen.

Das Dollarzeichen bei Strings kennen wir aus einem vorigen Kapitel – sogenannte String Interpolation. Die Backslashes vor den Anführungszeichen sorgen dafür, dass die Anführungszeichen nicht den String beenden, sondern Bestandteil des Strings sind.

Analog verfahren wir bei den eigentlichen Zeilen – nur, dass wir für die Zielsprachen einfach leere Felder einfügen.

Dafür definieren wir eine kleine Lambda-Funktion namens CreateLine, die drei Strings entgegennimmt – den Key, den deutschen Wert und den Zielsprachen-Teil – und daraus eine Zeile erzeugt.

Wir initialisieren unsere Zeilenliste mit der Überschrift, rufen dann Concat() auf, um die einzelnen Zeilen anzuhängen.

Jedes KeyValuePair wird also mit CreateLine verarbeitet – und das ergibt am Ende die komplette CSV-Datei.

---

### CSV-Datei schreiben

Fehlt noch der Schreibvorgang: Der Dateiname hat sich als etwas tricky erwiesen. Also habe ich die CommandInfo-Klasse um eine Property OutputPath erweitert – hier ist der Pfad zur Datei, in die gespeichert werden soll.

.NET stellt dafür die Methode File.WriteAllLines(...) zur Verfügung – wir übergeben den Pfad aus OutputPath und unsere List<string> mit den CSV-Zeilen.

---

### Ein Wort zum Programmierstil
Zum Schluss noch ein Wort zum verwendeten Programmierstil: Die Art, wie dieser Code geschrieben ist, mag anfangs etwas verwirrend oder überkompliziert wirken. Tatsächlich ließen sich viele der hier verwendeten LINQ-Statements und Lambdas auch traditioneller mit foreach-Schleifen und einfacherem Code formulieren.

Wir verwenden hier jedoch einen eher funktionalen Programmierstil, der in den letzten Jahren zunehmend Einzug in die Sprache C# gehalten hat. Man könnte sagen:
Man programmiert nicht mehr das Wie, sondern das Was.

Das ist anfangs gewöhnungsbedürftig, führt aber zu kompakterem, lesbarerem und leichter testbarem Code.

Auf LinkedIn Learning gibt es übrigens einen tollen Kurs zur funktionalen Programmierung mit C# (auf Englisch – die deutsche Version ist in Vorbereitung). Wenn Sie lernen möchten, funktionale Elemente gezielt einzusetzen, sind Sie auf dem besten Weg zu einem modernen, zeitgemäßen Programmierstil – und bereit, mit der weiteren Entwicklung von C# Schritt zu halten.


---


### Ausprobieren
Diesmal starten wir das Programm nicht im Debugger, sondern direkt im Terminal:

```bash
dotnet run ResxToCsv Demo.de.resx en fr
```

Nach dem Build sollte die CSV-Datei im Ausgabeverzeichnis erscheinen.
