## Aufbau einer Konsolenanwendung  

Sehen wir uns zunächst die **Dateistruktur** an, also die in einer Konsolenanwendung enthaltenen **Dateien und deren Funktion**.  

---

### Dateistruktur

Beim **Testen der korrekten Installation** der Entwicklungstools haben wir diese **Konsolenapplikation** hier angelegt.  
Das **dotnet-Tool** hat dabei folgende **Dateien** erstellt, die wir uns hier genauer ansehen:  

---

#### **1. .csproj-Datei**  
Dies ist die sogenannte **C#-Projektdatei**.  
Sie enthält **Anweisungen für den Compiler**, wie das **ausführbare Programm** erzeugt werden soll.  
Daraus geht zum Beispiel hervor:  
- Dass das Projekt das **Microsoft .NET SDK** verwendet.  
- Dass als **Output Type** eine `.exe`-Datei (also eine ausführbare Datei) erzeugt wird.  
- Dass das **Target Framework** auf `.NET 9` gesetzt ist.  
- Und noch viele weitere Einstellungen zur sogenannten **Build-Konfiguration**.

---

#### **2. Solution-Datei (.sln)**  
Die **Solution-Datei** ist eigentlich nur eine **Liste von Projekten**, die zu einer **Anwendung** gehören.  
Sie hilft dabei, **mehrere Projekte** zu organisieren, die zusammen die **Anwendung** bilden. Erzeugt wird sie automatisch beim Anlegen eines Projekts in VSCode.

---

#### **3. .cs-Dateien**  
Die **.cs-Dateien** enthalten **Ihren Code** – also das, was das Programm **letztlich tun soll**.  
Hier wird die **Logik der Anwendung** definiert und implementiert.  

Also, bei einem Blick in unsere Program.cs-Datei sehen wir nur eine Zeile: Eine Konsolenausgabe. Diese wurde im Projekt-Template für die Konsolenanwendung so definiert, um einfach etwas Code zu haben.  

---

#### Compiler-"Magie"
Hier zeigt sich auch eine Besonderheit des Compilers, nämlich dass er die eigentliche Programmstruktur für uns Entwickler vereinfacht. Das kann man sich sehr schön veranschaulichen, indem man das Programm dekompiliert.  

Eigentlich sollte nämlich hier ein sogenannter Entry Point, also ein Einstiegspunkt für den Programmablauf, zu sehen sein.  
Sehen wir uns dazu die Dekompilierte Version des Programms an.  

---

#### Decompiler
Wir haben hier die Webseite von **CodeMerxDecompile**, einem freien .NET-Dekompiler, der auf allen Plattformen läuft. Wenn man mit diesem Dekompiler unser kompiliertes Programm lädt, also die entstandene DLL, sieht man, dass die Projektstruktur deutlich ausführlicher ist, als es die .cs-Datei vermuten lässt.  

Der Dekompiler zeigt uns die tatsächliche Struktur und den zusätzlichen Code, den der Compiler hinzugefügt hat.  

Für uns ist hier nur wichtig, dass jedes .NET-Programm mindestens eine Klasse definieren muss und eine zugehörige Methode, die als Einsprungspunkt in das Programm dient.  

Das ist der Code, der als allererstes ausgeführt wird und den Programmablauf startet.  
In C# ist das normalerweise die `Main()`-Methode.  

Der Dekompiler hilft uns also zu verstehen, wie dieser Einstiegspunkt vom Compiler tatsächlich umgesetzt wird. Beispielsweise gibt der Compiler dieser Einsprungsmethode hier diesen seltsam anmutenden Namen.  

Für uns ist das allerdings unerheblich, weil wir in der C#-Datei tatsächlich nur die eine Zeile gesehen haben, die die Konsolenausgabe anstößt.  

---

#### Klarere Struktur
Also, ich persönlich mag es etwas transparenter. Mir ist es wichtig, die komplette Projektstruktur inklusive der .NET-Klassen zu sehen.  

Legen wir uns doch ein neues Projekt an und berücksichtigen das.  
Dazu ist es nötig, dass wir in **Visual Studio Code** im richtigen Verzeichnis sind. Also navigieren wir über das Terminal in unser Projektverzeichnis.  

Dann rufen wir über **Strg + Umschalt + P** die Methode `dotnet new` auf und wählen dort **Konsole** aus, um eine Konsolenanwendung zu erstellen.  

Wie wärs mit **Projektstruktur** als Name.  

Wir vergewissern uns, dass das Verzeichnis, in dem das dotnet-Tool das Projekt anlegen wird, unser aktuelles Projektverzeichnis ist.  
Hier wählen wir alle Vorlagen-Optionen so aus, dass **keine Anweisungen der obersten Ebene verwendet** werden.  Wir wollen also die Main-Methode und die Klasse Program sehen.

Mit der **Eingabetaste** lassen wir das dotnet-Tool seine Wunder wirken.  

Anschließend navigieren wir in das Verzeichnis des neuen Projekts und öffnen **Visual Studio Code** in diesem Verzeichnis mit `code . -r`. Das `-r` steht für **reuse window** und sorgt dafür, dass **Visual Studio Code im aktuellen Verzeichnis** geöffnet wird, ohne eine neue Instanz zu starten.  

Ein Blick in Program.cs zeigt uns, dass wir nun die Klasse Program haben und darunter die statische Einsprungmethode Main().  

Nun, man kann das auch nachträglich ändern, wenn man hier in VSCode Strg + . angibt, kann man zwischen den beiden Varianten hin- und herwechseln...

Nun zur logischen Struktur, also dem typischen Inhalt einer Konsolenanwendung. Vorher indes noch zwei wichtige Grundprinzipien, die in jeder Konsolenanwendung zum Tragen kommen.  
