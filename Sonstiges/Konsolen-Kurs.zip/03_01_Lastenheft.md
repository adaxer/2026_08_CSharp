## Ausgangspunkt: Eigenes Projekt und Ziel  
Hier unser erstes Praxisprojekt:  
Ein Tool zum **Konvertieren von `.resx`-Dateien in `.csv`-Dateien** und zum **Zurückschreiben der `.csv`-Dateien in `.resx`-Dateien**.

Das Projekt hier ist eine **etwas abgespeckte Version** einer Funktionalität, die ich in einem  Kundenprojekt implementiert habe.  

---

### Ausgangspunkt
Viele .NET-Programme verwenden `.resx`-Dateien,  
um ihre Zeichenketten in unterschiedlichen Sprachen abzubilden.  

#### Resx-Datei
Hier sehen Sie ein solches `.resx`-File,  
das mit Visual Studio generiert wurde und die Texte eines typischen Programms auf Deutsch enthält.  

Die Daten sind im **XML-Format** gespeichert,  
und zum Glück enthält .NET **Libraries**, mit denen man XML sehr komfortabel bearbeiten kann.  

#### CSV-Datei
Ein Übersetzungsbüro könnte diese Texte in die Zielsprachen **Englisch** und **Französisch** übersetzen und uns eine `.csv`-Datei zurückschicken, die wir wieder in `.resx` umwandeln können.  

#### Das Rad neu erfinden?
Natürlich gibt es kommerziell Tools, die bei der Übersetzung helfen – allerdings haben wir immer wieder festgestellt, dass man die Daten irgendwie **nachbearbeiten** muss oder dass es **eigene Zwischenschritte** gibt, die je nach Richtung der Konvertierung notwendig sind.

Also sind wir am flexibelsten, wenn wir diese Aufgabe mit **eigenem Code** meistern.  

Daher schreiben wir uns eine Konsolenapplikation, die genau diese Aufgaben übernimmt.  

Dann gehen wir die Aufgabe nun **Schritt für Schritt** an.

#### Originaldatei
Die Originaldatei aus dem erwähnten Kundenprojekt hier enthält einen sehr langen Kommentar, gefolgt von einem umfangreichen XML-Schema und einigen sogenannten resheader-Elementen. Darunter folgen viele data-Tags, in denen die Nutzdaten abgelegt sind.

Den Kommentar und das Schema können wir in unserem Projekt weglassen – die .NET-Build-Tools können die `.resx`-Datei auch so problemlos verarbeiten. Die data-Tags sind natürlich wichtig.

#### Angepasste Ausgangsdatei
In unserem Projekt arbeiten wir mit der Datei `Demo.de.resx`, die einige beispielhafte deutsche Begriffe enthält. Diese verwenden wir, um für unser Übersetzungsstudio die CSV-Datei zu generieren. 

#### Ausgangsdatei in Csv
Die Resx-Datei soll zunächst in diese Csv-Datei umgewandelt werden. Sie enthält die Keys und den Originaltext (in Deutsch) sowie Spalten der Zielsprachen ohne Inhalt. 

#### Übersetzte Datei in Csv
Nach der Übersetzung würden wir die CSV-Datei ungefähr in dieser Form wieder zurückbekommen. Wie man sieht, enthält sie englische und französische Übersetzungen.

Aus dieser Datei sollen dann die Resx-Dateien der Zielsprachen erzeugt werden. Wir sehen sie hier.

Gehen wir nun die Aufgabe an, aus der `.resx`-Datei die CSV-Datei zu erzeugen, die wir dem Übersetzungsbüro schicken werden.

Falls Sie sich übrigens wundern, wie mein Explorer die Dateien so schön anzeigt, das ist ein sehr nützliches Utility für Windows, die sogenannten Power Toys. Sie enthalten unter anderem einen sehr schönen Datei-Previewer.
