## Warum Konsolenanwendungen  

### Aufgabenbereiche
Konsolenanwendungen bieten sich für viele Aufgaben an:
- Automatisierung und Skripte  
- Text- und Datenverarbeitung  
- System- und Netzwerkverwaltung  
- Entwicklung und Build-Tools  
- Utility-Programme  
- Informations- und Hilfsprogramme  
- Spiele und Unterhaltung  
- Kommunikation und API-Interaktionen  
- Sicherheit und Verschlüsselung  
- Lern- und Trainingsprogramme  

Damit sind einige, aber längst noch nicht alle Einsatzgebiete genannt.

---

### Einfachheit
Konsolenanwendungen haben kein oder aber ein stark vereinfachtes User Interface, sind daher also leichter zu programmieren und gehen sparsamer mit Systemressourcen um. Typischerweise steuert man sie über Kommandos und Optionen als Argumente. 

Sie lassen sich außerdem wesentlich einfacher debuggen und veröffentlichen.

Somit sind sie auch einfacher zu starten und werden auf allen Plattformen funktionieren, die .Net unterstützen.

Haben sie Lust darauf, loszulegen? Dann installieren wir jetzt unsere Tools und starten durch.
