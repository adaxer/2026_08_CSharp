## Struktur einer Konsolenanwendung  

Betrachten wir die **logische Struktur**  – also das, was Sie als **Funktionalität** in Ihrer Konsolenanwendung definieren.  

---

### Eingabe  
Wie schon gehört, bilden Konsolenanwendungen das EVA-Prinzip der Informatik ab.  

Schauen wir uns nun in unserer Konsolenapplikation an, wie man Eingaben verwenden kann.  

---

#### ReadLine
Die einfachste Variante, speziell in interaktiven Applikationen, ist das Einlesen von Werten über Console.ReadLine().  

Wir beginnen, indem wir  Namen und Alter abfragen und in Variablen speichern. Den Namen speichern wir in der Variable name und das Alter in der Variablen age. Dabei wandeln wir den eingegebenen Wert mit der Methode int.Parse() in einen Zahlenwert um. Falls der Wert leer ist oder keine korrekte Zahl enthält, wird hierbei ein Fehler passieren. Wir lernen später, wie man damit umgeht.  

Diesen Teil der Anwendung überschreiben wir vorerst mit dem Kommentar // Eingabe. Den Verarbeitungsteil überschreiben wir mit dem Kommentar // Verarbeitung. Wir machen es uns hier noch einfach, indem wir einen Gruß mit dem Namen und einem Geburtstagswunsch zusammensetzen. Im Teil der Ausgabe geben wir diesen Gruß auf der Konsole aus.  

Wenn wir das Programm laufen lassen, fragt es uns nach unserem Namen und Alter und gibt das Ergebnis entsprechend aus.  

Tatsächlich können wir hier schon den Eingabekanal umschalten und eine Pipe verwenden. Das geht über das Kommando:  

`echo "Hans\n30" | dotnet run`

Das \n simuliert sozusagen einen Zeilenumbruch.  
So bekommt Console.ReadLine() die Eingaben genauso, als ob wir sie manuell Zeile für Zeile eingeben würden. 

Probieren wir noch etwas anderes aus: In der Eingabe geben wir statt der 30 das Wort dreißig ein und leiten das Programm auf die Dateien out.txt bzw. err.txt um:  

`echo "Hans\ndreißig" | dotnet run > out.txt 2 > err.txt`

Es wird tatsächlich einen Fehler geben, weil das Wort dreißig nicht in einen Zahlenwert umgewandelt werden kann.  

Die Ausgaben erscheinen nun nicht mehr auf dem Bildschirm, sondern wie erwartet in out.txt bzw. err.txt  

---

#### Argumente
Eine weitere Möglichkeit, Daten in eine Konsolenanwendung einzugeben, ist über das Array (oder Feld) args. 

Hier machen wir das etwas schlauer: Wir lesen die Argumente aus dem Array args ein. Falls dort nichts eingegeben wurde, fragen wir sie wie vorher von der Konsole ab. Dazu führen wir die beiden Variablen am Anfang der Methode Main() ein und verwenden einen if-Block, um abzufragen, ob Argumente angegeben wurden.  

Wie startet man das Ganze und übergibt dabei Argumente?  

Das geht so:  
`dotnet run Hans 30`

Damit übergeben wir die Argumente direkt an das Programm.  
Tatsächlich sehen wir den Gruß wie erwartet in der Ausgabe.  

---

#### Steuerdatei
Als weitere Option verwenden wir jetzt eine sogenannte Steuerdatei.  

Wir prüfen dazu die Länge des Arrays args.  
Ist sie genau 1, interpretieren wir das eine Argument als Namen der Steuerdatei. In dieser Datei sollen nun der Name und das Alter stehen.  

Zum Einlesen der Daten verwenden wir hier die sogenannte Deserialisierung. (Serialisierung nennt man ein wichtiges Konzept der Programmierung: das Speichern und Laden von .Net-Objekten).  

Dazu müssen wir zunächst eine neue Klasse definieren. Nennen wir sie Person mit den beiden public Properties Name und Age. Also `dotnet new class Person` und wir definieren die Properties. 

Hier verwenden wir sogenannte Code Snippets. Im C# Dev Kit sind diese auch zum Werkzeugkasten von Visual Studio Code hinzugekommen. Im Detail darauf einzugehen würde den Rahmen dieses Kurses sprengen. Deshalb hier nur so viel:  

Mit dem Begriff prop gefolgt von einem Tab wird die Property erzeugt. Man kann dann direkt den Typ eingeben, weil dieser vorselektiert ist. Mit einem weiteren Tab kommen wir zum Namen und können diesen eingeben. Mit dem dritten Druck auf die Tab-Taste landen wir am Ende der Zeile und können die Datei weiterschreiben. Genau so verfahren wir mit der Property Age.  

Als zweiten Schritt erzeugen wir die Datei und nennen sie Hans30.json. Wir achten hierbei darauf, dass die Datei in korrekter JSON-Syntax formuliert ist. Das Objekt muss in geschweifte Klammern gesetzt werden. Die Namen der Properties müssen in Anführungszeichen stehen, ebenso der Wert für den Namen.  

Wir müssen nur noch dafür sorgen, dass die Datei vom Programm im Ausgabeverzeichnis gefunden wird. Um eine Datei direkt, also ohne Angabe des Pfades, einlesen zu können, muss sie im selben Verzeichnis wie das ausgeführte Programm sein. In "großen IDEs" wie Visual Studio oder Rider gibt es dafür ein Feature, das das automatisch erledigt. In Visual Studio Code müssen wir das jedoch manuell in die Projektdatei eintragen. Wir fügen also eine sogenannte ItemGroup hinzu und darin ein XML-Element None mit einem Update-Attribut. Das sieht dann so aus:  
```xml
<ItemGroup>
  <None Update="Hans30.json">
    <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
  </None>
</ItemGroup>
```

Jetzt können wir die if-Abfrage hinzufügen. Falls genau ein Argument übergeben wurde, lesen wir zunächst die Datei mit dem Namen des Arguments ein. Dann verwenden wir den im .NET-Framework enthaltenen JsonSerializer, um den eingelesenen Text als JSON zu interpretieren und in ein Person-Objekt einzulesen. Anschließend setzen wir unsere Variablen name und age auf die entsprechenden Properties des Objekts.  

Auch hier ist wieder etwas unterkringelt. Dies warnt uns, dass die Variable person tatsächlich auch ein Nullverweis sein kann. Allerdings haben wir in diesem Stadium unseres Projekts noch keine wirkliche Fehlerbehandlung eingebaut. Das werden wir später nachholen.  

Fertig! Probieren wir es aus. Geben wir ein:  

`dotnet run Hans30.json`

Und wir sollten die erwartete Ausgabe sehen. Ich habe hier übrigens noch ein paar Konsolenausgaben eingebaut, die darauf hinweisen, woher die Eingabe kommt.  

---

#### Weitere Möglichkeiten

Es gibt noch einige weitere Möglichkeiten, woher die Eingabe kommen kann.  

Dazu gehören unter anderem:  
- AppSettings  
- Environment-Variablen  
- Eigene Implementationen  

Dies würde jedoch den Rahmen dieses Kurses sprengen. Allerdings gehe ich auf die hier erwähnten im Deep-Dive-Kurs zu Konsolenanwendungen ein.  
Schauen Sie bei Interesse gerne dort rein.  

---

### Ausgabe
Als Ausgabe haben wir hier schon die Konsole kennengelernt.  

Falls der Standardausgabekanal umgeleitet wurde, zum Beispiel in eine Datei, wird das automatisch erledigt.  

Wir können allerdings auch konkret Ausgaben in eine Datei schreiben.  

Machen wir das hier exemplarisch, indem wir eine kleine Nachricht in die Datei result.txt schreiben.
Wir finden sie hier  im Projekt-Verzeichnis.  

---

### Weiterführend: Commands und Options
Wir haben jetzt schon einige Möglichkeiten kennengelernt, wie wir Kommandozeilen- oder Konsolenanwendungen steuern können.  

Tatsächlich ist da noch viel mehr möglich.  

Konsolenprogramme können über Commands gesteuert werden, die Argumente erhalten.  
Es können Optionen eingegeben werden, meist mit vorangestellten Minus-Symbolen.  

Die Steuerung kann teils interaktiv erfolgen, indem Default-Optionen gesetzt werden, die man nachträglich ändern kann.  

All dies sind Dinge, die mit Bordmitteln von .NET umständlich zu lösen sind.  

Es gibt aber zusätzliche Pakete, die man Konsolenanwendungen hinzufügen kann und damit sehr mächtige Möglichkeiten bekommt,  
übergebene Argumente auszuwerten und daraus Commands und Optionen abzuleiten.  

Im Deep-Dive-Kurs zur C#-Konsole werde ich einige dieser Pakete vorstellen und  damit noch weiter in die Tiefe gehen.  

---

Hier sind wir fürs Erste fertig und werden im nächsten Abschnitt die Console-Klasse genauer unter die Lupe nehmen, um aus der Konsole noch mehr herauszuholen.  

Zum Beispiel:  
- Vorder- und Hintergrundfarben ändern  
- Cursor verstecken
- Konsolenausgaben an bestimmte Positionen am Screen platzieren
- Konsolenapplikationen asynchron starten  



