## Exceptions behandeln

Viele glauben, Exceptions seien katastrophale Fehler – das stimmt so nicht. Jede Anwendung folgt einem sogenannten „Happy Path“. Exceptions treten auf, wenn der Programmablauf durch äußere Umstände davon abweicht – etwa durch fehlende Dateien, gesperrte Ressourcen oder unterbrochene Internetverbindungen.

Mit solchen Ausnahmefällen kann und sollte man rechnen – durch sogenanntes Exception Handling.

---

### Exceptions im Projekt

In unserem Projekt erwarten wir gültige Eingaben: ein Kommando, eine existierende Datei, die passende Inhalte enthält, sowie gültige Sprachcodes.

Wenn **gar keine Argumente** übergeben werden, haben wir das bereits gelöst: `CommandInfo.Create()` erkennt das und liefert eine `None`-Instanz zurück – das Menü wird (später) angezeigt.

---

### Fehlerhafte Eingaben

Die Methode `Create()` versucht dann:
- das erste Argument als Kommando zu parsen,
- das zweite Argument als Datei zu öffnen,
- und alle weiteren Argumente als Sprachcodes zu interpretieren.

Nun könnten wir für all das `if`-Abfragen schreiben – aber das wäre unübersichtlich und kaum wartbar. Die erste wichtige Regel lautet daher: **Versuchen Sie nicht krampfhaft, Exceptions zu verhindern.**

---

### Exceptions bewusst zulassen

Gerade schwer vorhersehbare Eingabefehler (z. B. vertauschte Argumente, Tippfehler etc.) lassen sich nicht sauber durch Prüfungen verhindern. Also besser: **Fehler zulassen – und richtig behandeln.**

Mit `try-catch` lässt sich gezielt auf bestimmte Exceptions reagieren. In größeren Applikationen ist es üblich, Exceptions differenziert zu behandeln. In unserem kleinen Tool genügt ein einfacher Catch-Block für alle.

Tritt eine Exception auf, geben wir die Fehlermeldung (`ex.Message`) aus, brechen die Verarbeitung ab und zeigen zusätzlich eine `Usage`-Anleitung an. Das ist ein kleiner Hilfetext, der den Anwendern erklärt, was das Programm macht und welche Parameter es in welcher Reihenfolge erwartet.

Auch try-catch ist übrigens ein sogenanntes Codesnippet, also ein Makro in Visual Studio Code. Wir geben die Exception auf dem Errorkanal aus. Damit beendet sich das Programm und die Anwender Wissen, dass etwas schief gegangen ist. In dem Stacktrace hier steht der genau Ort, wo die Exception auftrat. 

---

### Fazit

So wissen die Anwender, was sie falsch gemacht haben. In größeren Projekten gehört dazu natürlich deutlich mehr – z. B. differenzierte Fehlerklassen, Logging, globale Exception-Handler usw.

Wenn Sie sich tiefer einarbeiten möchten, wir haben einige C#-Komplettkurse und Architektur-Kurse, die das Thema behandeln. Auch ich plane einen Kurs speziell über den Umgang mit Exceptions in näherer Zukunft.

So, nun aber in medias res. Lesen wir unser xml ein!
