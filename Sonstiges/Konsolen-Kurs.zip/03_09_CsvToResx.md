
## Rückweg: CSV nach `.resx` konvertieren

Wir haben aus `.resx` eine CSV-Datei erzeugt. Jetzt nehmen wir an, dass wir die Datei `Demo.Translation.csv` vom Übersetzungsbüro zurückbekommen haben. Diese enthält für jede Zielsprache die übersetzten Texte. Unsere Aufgabe ist es nun, daraus wieder `.resx`-Dateien zu erzeugen.

---

### CSV vorbereiten

Hier ist Vorsicht geboten: Die Texte könnten **Anführungszeichen** oder **Kommas** enthalten. Der Einsatz von regulären Ausdrücken wäre denkbar – wir machen es hier nur mit **Stringfunktionen**.

Zuerst entfernen wir das erste und letzte Anführungszeichen (`Trim('"')`). Dann ersetzen wir `","`) mit einem Zwischenzeichen, z. B. `||`. Ebenso ersetzen wir die Kombination `"↵"` durch ein anderes Zwischenzeichen. Danach splitten wir den Text an den Zeilentrennzeichen.

Für jede Zeile trennen wir dann die Spalten anhand des gewählten Zwischenzeichens.

---

### Datenstruktur aufbereiten

Wir vergewissern uns im Debugger, dass wir eine Liste mit gleich langen `string[]`-Arrays erhalten.

Dann extrahieren wir die Überschriftzeile – die ersten beiden Spalten ignorieren wir, die restlichen geben uns die Zielsprachen. Diese speichern wir in einer Liste `languages`.

Für jede Zielsprache erzeugen wir nun:

- den passenden Dateinamen für die `.resx`-Datei (`Demo.en.resx` etc.)
- ein Dictionary mit Key/Value-Paaren – jeweils aus erster Spalte (Key) und entsprechender Sprachspalte (Value)

---

### XML-Datei erzeugen

Diese Dictionaries übergeben wir einer ausgelagerten Methode `CreateResx`.

Dort verwenden wir wieder LINQ to XML – diesmal **zum Schreiben**:

- Wir erzeugen ein `XElement root`
- Fügen zunächst die `resheader`-Elemente hinzu (aus einer `readonly List<XElement>`)
- Danach fügen wir alle `data`-Einträge hinzu. Jeder besteht aus:
  - einem Tag `<data name="..." xml:space="preserve">`
  - einem Unterelement `<value>Text</value>`

Wichtig: Das Attribut `xml:space="preserve"` sorgt dafür, dass **Leerzeichen** und **Zeilenumbrüche** erhalten bleiben – auch bei der Anzeige in UI-Tools.

Der `xml:`-Namespace wird durch die Formulierung im Code hier automatisch korrekt eingebunden.

---

### Ergebnis prüfen

Im Debugger sehen wir ein korrekt erzeugtes XML-Element. Nach dem Schreiben können wir uns die `.resx`-Dateien im Projektverzeichnis ansehen.

---

### Nächste Schritte

Damit ist die Funktionalität unseres `LocalizeHelper` abgeschlossen.

Was noch fehlt:
- die `Usage`-Ausgabe
- das Anzeigen des Menüs inkl. Interaktion

Darum kümmern wir uns im nächsten Video – und in der Übung zu diesem Kapitel bauen Sie dann passende Textausgaben ein, sodass man bei der Anwendung auch mitbekommt, was das Programm getan hat.
