## Die Klasse Console 
Wir haben hier in Visual Studio Code ein neues Konsolenprojekt begonnen und es **ConsoleClass** genannt.  

In der `Main`-Methode des Programms spielen wir nun mit den Möglichkeiten der `Console`-Klasse.  

---

### Console.Title
Als Erstes setzen wir den **Titel**.  
Setzen wir ihn doch auf den Text `"Die Klasse \"Konsole\""`.

Übrigens: Hochkommas kann man mit einem vorangestellten Backslash (`\`) in die Textausgabe übernehmen, sodass sie letztendlich im Titel erscheinen.  

Das Problem ist hier allerdings: Wenn wir die Applikation in Visual Studio Code starten – entweder im Debugging-Modus, so wie wir das vorher schon gemacht haben, oder über `dotnet run` hier im Terminal – können wir natürlich keinen Titel sehen, da die Konsole hier kein komplettes Fenster ist.  

Das lösen wir wie folgt:  
Wir starten eine Kommandozeile oder das **Windows Terminal**.  

Übrigens: Das Windows Terminal ist eine tolle Applikation, mit der man unterschiedliche Terminal-Sitzungen in Tabs darstellen kann.  
Es zu installieren lohnt sich. Sie finden es im Microsoft App Store.  

Ok, wir haben hier ein Terminal gestartet und navigieren in das Verzeichnis unserer Konsolenapplikation.  

Wenn wir jetzt `dotnet run` eingeben, sehen wir den gesetzten **Titel oben im Konsolenfenster**.

---

### Console.ReadKey
Wir haben ja bereits `Console.ReadLine` kennengelernt.  
Diese Methode ist praktisch, wenn man eine Eingabe einlesen will, die mit der **Enter-Taste** abgeschlossen wird.  

Es gibt allerdings noch weitere Funktionen:  
`Console.ReadKey` liest eine **einzelne Taste** ein – ohne dass die Eingabe mit Enter abgeschlossen werden muss.  

Schauen wir uns das in einem Beispiel an:  
Wir weisen die Variable `key` dem von der Konsole gelesenen Key zu und geben das Ganze anschließend auf der Konsole aus.  

Was wir sehen, ist offensichtlich eine Instanz der `ConsoleKeyInfo`-Klasse.  

Betrachten wir das in der Dokumentation von .NET, sehen wir, dass die `ConsoleKeyInfo`-Klasse im Wesentlichen zwei Eigenschaften hat:  
- **Key** – die Taste selbst  
- **Modifiers** – ob gleichzeitig z. B. **Umschalttaste (Shift)** oder **Steuerungstaste (Ctrl)** gedrückt wurde  

Wenn wir uns das `ConsoleKey`-Enum anschauen, sehen wir, dass hier sämtliche Tasten der Tastatur erfasst sind.  

Also wandeln wir unser Programm etwas ab und geben aus:  
- **Welche Taste** gedrückt wurde  
- **Welche Modifier** (z. B. Shift, Ctrl) aktiv waren  

Setzen wir das Ganze in eine **Endlos-Schleife**, dann können wir wunderbar experimentieren und uns verschiedene Tasten- und Modifier-Kombinationen anschauen.

---

### Console.KeyAvailable
`Console.ReadKey` wartet, bis eine Taste gedrückt wurde. Damit ist das Programm **blockiert**, solange keine Eingabe erfolgt.  

Hierfür gibt es die Funktion `Console.KeyAvailable`.  

Sehen wir uns das an:  

Zunächst kommentieren wir die erste `ReadKey`-Schleife aus.  

Dann verwenden wir eine weitere Schleife, die das **Warten simuliert** oder eine andere Aktion ausführt – also die "Hauptarbeit" des Programms –, ohne dass es blockiert.  

Sobald eine Taste gedrückt wurde, können wir das durch `Console.KeyAvailable` erkennen.  

Wenn `KeyAvailable == true` ist, rufen wir `Console.ReadKey()` auf und zeigen die gedrückte Taste an.  

So bleibt das Programm **reaktiv**, kann weiterhin Aufgaben erledigen und **reagiert trotzdem** sofort auf Tasteneingaben.

Hier habe ich übrigens `Thread.Sleep` verwendet – was im Allgemeinen **nicht zu empfehlen** ist. Es eignet sich eher für **Demonstrationen**. 

Für produktiven Code gilt:  
**Lieber `await Task.Delay(...)` als `Thread.Sleep(...)`.** - Hierzu gleich ein Beispiel...

Als weitere Eingabemöglichkeit ist noch `Console.Read` zu nennen.  

Wir machen hier kein Beispiel dazu, aber schauen Sie sich diese Methode gerne in der offiziellen Dokumentation an.  

Sie eignet sich für spezielle Anwendungsfälle, in denen einzelne Zeichen als Ganzzahlen eingelesen werden sollen.

---

### Console.Write
`Console.Write` ist ähnlich wie `Console.WriteLine`,  
nur dass **nach der Ausgabe kein automatischer Zeilenumbruch** erfolgt.  

Das bedeutet, der nächste Text wird direkt **in derselben Zeile** fortgesetzt.  

Im nächsten Abschnitt sehen wir ein umfangreicheres Beispiel dazu.

---

### Bunte Console
Man kann die **Hintergrund-** und **Vordergrundfarben** (also die Schriftfarbe) der Konsole einstellen.  

In unserem `ConsoleClass`-Beispiel setzen wir einfach mal **blau auf weiß**:  
- `Console.BackgroundColor = ConsoleColor.White;`  
- `Console.ForegroundColor = ConsoleColor.Blue;`  

Nach dem `ReadKey`-Beispiel setzen wir die Farben wieder zurück mit:  
```csharp
Console.ResetColor();
```

---

### Cursor setzen und Fenstergrößen
Betrachten wir die Methoden 
- `Console.Clear`: Löschen des Ausgabefensters, 
- `Console.SetCursorPosition`: Platzieren des Cursors für die nächste Ausgabe
- `Console.Write`: Schreiben an die aktuelle Cursor-Position

Betrachten wir weiterhin die Eigenschaften
- `Console.WindowHeight`: Höhe des Ausgabefensters  
- `Console.WindowWidth`: Breite des Ausgabefensters

Hiermit können wir die Konsole zu einer kleinen graphischen, interaktiven Anwendung aufpeppen, um beispielsweise **mittig ein Menü anzuzeigen**.

Das folgende Beispiel zeigt dies.
