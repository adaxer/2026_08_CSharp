## Einleitung  
Eine Konsolenapplikation ist ein Programm, mit dem man automatisierbare Aufgaben lösen kann.  
Im Gegensatz zu größeren Anwendungen kommt dieser Typ mit minimalem User Interface aus. Dadurch sind Konsolenapplikationen leichter zu programmieren.  

---

### Kursziel und Inhalt
Ziel dieses Kurses ist es, Sie in die Entwicklung von Konsolenapplikationen mit C# einzuführen.  
Zu Beginn erstellen wir eine kleine Konsolenapplikation. Damit lernen Sie zunächst grundlegende Funktionalitäten von Konsolenapplikationen kennen,  
zum Beispiel die Einstellung der Textfarbe, die Festlegung der Position für die Bildschirmausgabe oder das Verstecken des Cursors.  
Anhand praktischer Beispiele lernen Sie dann, noch mehr aus Konsolenapplikationen herauszuholen.  
Sie erfahren dabei, wie Sie Kommandos und Argumente verarbeiten. Sie werden verstehen, wie man eine Applikation in VsCode debuggen kann. 
Und mit dem Gelernten aus diesem Kurs können Sie viele alltägliche Aufgaben automatisieren. Aus den Praxisbeispielen nehmen Sie z.B. mit, 
- wie man (asynchron) Dateien liest und schreibt. Und das in jeder Plattform (Windows, MacOS und Linux!)
- wie man Objekte lädt und speichert (auch Serialisierung genannt)
- wie man mit Linq Xml-einliest und verarbeitet
- wie man Csv-Dateien liest und schreibt

Weiterhin lernen Sie anhand des Windows Terminals, mit Kommando-Shells umzugehen, und wie sie Ihre Konsolen-Applikationen Endusern zugänglich machen, also das Deployment. 

---

### Für wen ist dieser Kurs?  
- Wenn Sie kleine, wiederkehrende Aufgaben haben und bereits etwas Einblick in .NET hatten, dann ist dieser Kurs für Sie.  
- Ist die Programmierung mit .NET und C# komplettes Neuland für Sie, empfehlen wir Ihnen einen unserer Einführungskurse.  
- Haben Sie schon intensiv mit .NET gearbeitet und Konsolenapplikationen programmiert, dann schauen Sie sich doch einmal unseren Kurs **"Konsolenapplikationen Deep Dive"** an, der demnächst erscheint und auf diesem hier aufbaut. Trotzdem ist es durchaus möglich, dass Sie das eine oder andere Neue aus diesem Kurs mitnehmen...  

---

### Verwendete Tools  
Wir verwenden als Sprache **C#**. Natürlich kann man C#- und .Net-Applikationen mit "großen" Entwicklungsumgebungen wie Microsoft Visual Studio oder JetBrains Rider entwickeln. Wenn Sie eines davon kennen, spricht nichts dagegen, es zu verwenden. Ich habe hier **Visual Studio Code** gewählt, weil es
- kostenlos ist
- auf allen Betriebssystemen läuft
- einfach einzurichten ist
- und die Verwendung von Kommandozeilen-Tools verdeutlicht. 

Viele Aufgaben wie Build und Veröffentlichung lösen wir mit der Dotnet-Kommandozeile. Mehr ist nicht nötig. 
Zu Beginn richten wir .Net sowie unsere Entwicklungsumgebung ein, sodass Sie direkt loslegen können. 

### Code und Übungen
Den Code zu diesem Kurs – also die C#-Projekte und die Übungsaufgaben – finden Sie in meinem GitHub-Repository unter folgendem Link:

[https://github.com/adaxer/WieGehtCsConsole.git](https://github.com/adaxer/WieGehtCsConsole.git)

Also, los geht's!
