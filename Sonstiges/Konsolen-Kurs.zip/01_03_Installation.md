## Installation  

Sollte Ihr **Visual Studio Code** bereits für die **.NET**- und **C#**-Entwicklung eingerichtet sein,  
können Sie die folgenden Schritte natürlich **überspringen**.  

---

### Dotnet
Installieren wir als erstes .net:

Wenn Sie in der Suchmaschine Ihrer Wahl **.NET** eingeben, landen Sie auf der Website von Microsoft. Wie Sie sehen, ist .NET für alle Plattformen verfügbar. Klicken Sie auf **Download**, und normalerweise sollte Ihnen automatisch die Version für Ihre Plattform angeboten werden (bei mir ist es hier **Windows**).  

Nach erfolgreicher Installation steht **.NET** als Konsolenanwendung zur Verfügung (also ja, auch **.NET** ist ein Konsolenprogramm 😄).  
Wenn wir das Kommando `dotnet --version` eingeben, antwortet das Programm mit der aktuellen Version (in meinem Fall **Version 9**).

---

## Visual Studio Code
Weiter geht's mit **Visual Studio Code**.  
Wenn wir in einem Browser `vscode` eingeben, landen wir auf der Website von **Visual Studio Code**. Auch dieses Tool ist für alle Plattformen verfügbar. Installieren Sie es also für Ihr Betriebssystem.

---

## C# Dev Kit
Als letztes bereiten wir **Visual Studio Code** für die C#-Entwicklung vor. Klicken Sie dazu links auf das **Extensions-Icon**.  
Es öffnet sich die **Extensions-Oberfläche**. Suchen Sie dort nach **C# Dev Kit** und installieren Sie es.

Sie können das **C# Dev Kit** kostenlos verwenden. Dafür müssen Sie sich allerdings bei **Microsoft** anmelden – entweder mit **Hotmail**, **Outlook**, **Live** oder jedem anderen **Microsoft-Konto**.  

Dann steht der Entwicklung mit **C#** in **Visual Studio Code** nichts mehr im Weg! 🚀

---

## Feuerprobe
Machen wir die Probe aufs Exempel!  
Wir öffnen das Terminal in **Visual Studio Code** mit der Tastenkombination `Ctrl + Ö`.  
Navigieren Sie in ein Verzeichnis Ihrer Wahl, zum Beispiel:  
```
cd C:\Temp
```
Nun geben Sie ein:  
```
dotnet new list
```
Sie sehen, es wird eine Liste von Applikationstypen angezeigt, die Sie mit **.NET** und **C#** neu anlegen können. Also geben Sie ein:  
```
dotnet new console -n HelloWorld
```
Nachdem **.NET** das Kommando ausgeführt hat, lassen Sie sich den Inhalt des Verzeichnisses anzeigen:  
```
dir
```
Wechseln Sie ins Verzeichnis:  
```
cd HelloWorld
```
Und geben Sie ein:  
```
dotnet run
```
Nach einer Weile (Download von Packages und Kompilieren) sollten Sie die Ausgabe **"Hello World"** sehen. 🚀

Woher dieser Text **"Hello World"** kommt? Keine Sorge! 

Wir sehen uns den Aufbau und die **Struktur eines Konsolenprogramms** gleich genauer an. 



