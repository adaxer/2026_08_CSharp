Möchten Sie mit C# leistungsfähige Konsolenanwendungen schreiben, die sich ideal für automatisierbare Aufgaben eignen? Verarbeiten Sie Eingaben, steuern die Ausgabe, erzeugen Sie interaktive Menüs  – und dies auf Windows, MacOS und Linux.

Anhand praxisnaher Beispiele lernen Sie Schritt für Schritt, solche Programme zu entwickeln – vom ersten Code bis zur Veröffentlichung. Dabei verwenden Sie Tools wie das Windows Terminal, das Dotnet-CLI und Visual Studio Code.

Ich bin Andreas Daxer, freier Trainer, Berater, Architekt und Entwickler für .NET – und ich zeige Ihnen, wie viel Potenzial in einfachen Programmen steckt.

Tauchen wir ein in die Welt der Konsolenanwendungen!
